export default {
  login: 'Login',
  signup: 'Sign Up',

  email: 'Email',
  password: 'Password',

  chat: 'Chat',
  message: 'Message',

  error: 'Error',

  you: 'You',

  placeholder: 'There are no messages yet',
}
