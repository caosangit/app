export { default } from './Component'
